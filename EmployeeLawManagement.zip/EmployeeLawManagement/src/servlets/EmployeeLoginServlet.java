package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Employee;
import utils.CommonUtils;


@WebServlet("/loginEmployee")
public class EmployeeLoginServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String eemail = request.getParameter("eemail");
		String epassword = request.getParameter("epassword");
		String edesignation = request.getParameter("edesignation");
		CommonUtils u = new CommonUtils();
		Employee emp = u.validateEmployee(eemail, epassword, edesignation);
		if(emp != null && emp.getEdesignation().equals("Employee")){
			HttpSession session = request.getSession();
			session.setAttribute("emp",emp);
			response.sendRedirect("EmployeeHome.jsp");
		}else if(emp != null && emp.getEdesignation().equals("Officer")){
			HttpSession session = request.getSession();
			session.setAttribute("emp", emp);
			response.sendRedirect("OfficerHome.jsp");
		}
		else {
			String message="Invaild ID/ Password/ Designation";
			request.getSession().setAttribute("message", message);
			response.sendRedirect("Login.jsp");
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	

}

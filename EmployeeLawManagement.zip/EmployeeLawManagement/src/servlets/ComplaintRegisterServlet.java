package servlets;

import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Employee;
import bean.Request;
import bean.Sections;
import utils.RequestUtils;



@WebServlet("/registerComplaint")
public class ComplaintRegisterServlet extends HttpServlet {
	
	


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		
			
			int eid=Integer.parseInt(request.getParameter("eid"));
		
		int sid=Integer.parseInt(request.getParameter("sid"));
		int oeid=Integer.parseInt(request.getParameter("oeid"));
		
		String rdescription=request.getParameter("rdescription");
		File rfile=null;
		String rstatus= "PENDING";
		
		
		Employee emp=new Employee();
		
		emp.setEid(eid);
		
		Employee off=new Employee();
		off.setEid(oeid);
		
		Sections sec=new Sections();
		sec.setSid(sid);
		Request rqst=new Request(0,rdescription,rfile,rstatus,emp,off,sec);
		
		RequestUtils u=new RequestUtils();
		if(u.registerComplain(rqst,oeid)) {
			request.setAttribute("action", "Complaint Registration");
			request.setAttribute("result", "success");
			RequestDispatcher dis = request.getRequestDispatcher("EmployeeHome.jsp");
			dis.forward(request, response);
			System.out.println("Complaint Registered..!");
		}else{
			request.setAttribute("action", "Complaint Registration");
			request.setAttribute("result", "failed");
			RequestDispatcher dis = request.getRequestDispatcher("prepareComplaint");
			dis.forward(request, response);
			System.out.println("Complaint Not Registered..!");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

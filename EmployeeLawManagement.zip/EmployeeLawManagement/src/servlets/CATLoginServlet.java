package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.CAuthority;
import bean.Employee;
import utils.CommonUtils;


@WebServlet("/loginCAT")
public class CATLoginServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		CommonUtils u = new CommonUtils();
		CAuthority caty=u.validateCAT(email, password);
		if(caty != null ){
			HttpSession session = request.getSession();
			session.setAttribute("caty",caty);
			response.sendRedirect("CATHome.jsp");
		}else {
			response.sendRedirect("Login.jsp");
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	

}

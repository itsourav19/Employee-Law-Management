package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.CAuthority;
import bean.Comments;
import bean.Employee;
import bean.Request;
import utils.CommonUtils;


@WebServlet("/WriteCommentByEmp")
public class WriteCommentByEmpServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int eid=Integer.parseInt(request.getParameter("eid"));
		int rid=Integer.parseInt(request.getParameter("rid"));
		String commenttext=request.getParameter("commenttext");
		
		Request rqst=new Request();
		rqst.setRid(rid);
		
		Employee emp=new Employee();
		emp.setEid(eid);
			
		Comments com=new Comments(0,commenttext,rqst,null,emp);
		CommonUtils u=new CommonUtils();
		if (u.writeCommentByEmp(com)) {
			RequestDispatcher dis = request.getRequestDispatcher("EmployeeHome.jsp");
			dis.forward(request, response);
			System.out.println("Comment Registered..!");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}

package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Employee;
import utils.EmployeeUtils;


@WebServlet("/updateEmployeeDetails")
public class UpdateEmployeeDetails extends HttpServlet {
	
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int eid = Integer.parseInt(request.getParameter("eid"));
		String ename = request.getParameter("ename");
		String eemail = request.getParameter("eemail");
		String epassword = request.getParameter("epassword");
		String eaddress = request.getParameter("eaddress");
		String edesignation = request.getParameter("edesignation");
		
		Employee emp= new Employee(eid,ename,eemail,epassword,edesignation,eaddress);
		
		EmployeeUtils u=new EmployeeUtils();
		if(u.updateEmployee(emp)) {
			HttpSession session = request.getSession(false);
			if(session != null)
				session.removeAttribute("emp");
			request.setAttribute("action", "Employee Updation");
			request.setAttribute("result", "success");
			RequestDispatcher dis = request.getRequestDispatcher("Login.jsp");
			dis.forward(request, response);
			System.out.println("Details Updated....!");
		}
		else{
			request.setAttribute("action", "Employee Updation");
			request.setAttribute("result", "failed");
			RequestDispatcher dis = request.getRequestDispatcher("ProfileUpdate.jsp");
			dis.forward(request, response);
			System.out.println("Details Updation  Failed....!");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

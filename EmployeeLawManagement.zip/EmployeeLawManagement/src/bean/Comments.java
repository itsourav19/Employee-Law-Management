package bean;

public class Comments {

	private int coid;
	private String commenttext;
	private Request rqst;
	private CAuthority caty;
	private Employee emp;

	public Comments() {
		super();
	}

	public Comments(int coid, String commenttext, Request rqst, CAuthority caty, Employee emp) {
		super();
		this.coid = coid;
		this.commenttext = commenttext;
		this.rqst = rqst;
		this.caty = caty;
		this.emp = emp;
	}

	public int getCoid() {
		return coid;
	}

	public void setCoid(int coid) {
		this.coid = coid;
	}

	public String getCommenttext() {
		return commenttext;
	}

	public void setCommenttext(String commenttext) {
		this.commenttext = commenttext;
	}

	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}

	public CAuthority getCaty() {
		return caty;
	}

	public void setCaty(CAuthority caty) {
		this.caty = caty;
	}

	public Request getRqst() {
		return rqst;
	}

	public void setRqst(Request rqst) {
		this.rqst = rqst;
	}

}

package bean;

public class Employee {
	 
	private int eid;
	private String ename;
	private String eemail;
	private String epassword;
	private String edesignation;
	private String eaddress;
	
	public Employee() {
		super();
	}

	public Employee(int eid, String ename, String eemail, String epassword, String edesignation, String eaddress) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.eemail = eemail;
		this.epassword = epassword;
		this.edesignation = edesignation;
		this.eaddress = eaddress;
	}
	

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEemail() {
		return eemail;
	}

	public void setEemail(String eemail) {
		this.eemail = eemail;
	}

	public String getEpassword() {
		return epassword;
	}

	public void setEpassword(String epassword) {
		this.epassword = epassword;
	}

	public String getEdesignation() {
		return edesignation;
	}

	public void setEdesignation(String edesignation) {
		this.edesignation = edesignation;
	}

	public String getEaddress() {
		return eaddress;
	}

	public void setEaddress(String eaddress) {
		this.eaddress = eaddress;
	}
	
	
}

package utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Employee;
import bean.Request;

public class RequestUtils {

	Connection conn = null;
	Statement stmt = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	//method Register complain/ Request
		public boolean registerComplain(Request rqst,int oeid) {
			boolean registered = false;
			
				conn = DBUtils.getConnection("employeelawdb");
				
				String sql = "insert into request (rdescription,rfile,rstatus,eid,oeid,sid) values (?,?,?,?,?,?)";
				
				pst = DBUtils.getPreparedStatement(sql);
				try{
				pst.setString(1, rqst.getRdescription());
				pst.setString(2, null);
				pst.setString(3, "PENDING");
				pst.setLong(4, rqst.getEmp().getEid());
				pst.setLong(5, oeid);
				pst.setLong(6, rqst.getSec().getSid());
				
				int r = pst.executeUpdate();
				
				if(r > 0){
					registered = true;
				}
				
				DBUtils.closeResources(rs,pst,stmt,conn);
				
			}catch(SQLException e){
				e.printStackTrace();
			}
			return registered;
		}
	
	//Method Update Complain/Request of specific rid
		
		public boolean updateComplain(Request rqst){
			boolean updated = false;
			String sql = "update request SET rstatus=? WHERE rid=?";
			conn = DBUtils.getConnection("employeelawdb");
			pst = DBUtils.getPreparedStatement(sql);
			
			
				try {
					pst.setString(1, rqst.getRstatus());
					pst.setInt(2, rqst.getRid());
				int r = pst.executeUpdate();
				if(r != 0){
					updated = true;
				
				}
				}catch (SQLException e) {
					e.printStackTrace();
				}
			DBUtils.closeResources(rs, pst, stmt, conn);
			return updated;
		}
		
		public boolean updateComplainDetails(String rid){
			boolean updated = false;
			String sql = "update request SET rdescription=?,rfile=?,rstatus=?,eid=?,oied=?,sid=? WHERE rid=?";
			conn = DBUtils.getConnection("employeelawdb");
			pst = DBUtils.getPreparedStatement(sql);
			Request rqst=new Request();
			try{
				pst.setString(1, rqst.getRdescription());
				pst.setString(2, null);
				pst.setString(3, rqst.getRstatus());
				pst.setLong(4, rqst.getEmp().getEid());
				pst.setLong(5, rqst.getEmp().getEid());
				pst.setLong(6, rqst.getSec().getSid());
				
				int r = pst.executeUpdate();
				if(r != 0){
					updated = true;
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
			DBUtils.closeResources(rs, pst, stmt, conn);
			return updated;
		}
		
		//Delete a complain/request of specific rid
		public boolean deleteComplain(int rid){
			boolean deleted = false;
			conn = DBUtils.getConnection("employeelawdb");
			String sql = "delete from request WHERE rid="+rid;
			stmt = DBUtils.getSimpleStatement();
			try{
				
				int r = stmt.executeUpdate(sql);
				if(r > 0)
					deleted = true;
				
			}catch(SQLException e){
				e.printStackTrace();
			}
			DBUtils.closeResources(rs, pst, stmt, conn);
			return deleted;
		}	
			

}

package utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Employee;


public class EmployeeUtils {

	Connection conn = null;
	Statement stmt = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	//Method Registeration of Employee
	public boolean registerEmployee(Employee emp){
		boolean inserted = false;
		try{
			conn = DBUtils.getConnection("employeelawdb");
			
			String sql = "insert into employee (ename,eemail,epassword,edesignation,eaddress) values (?,?,?,?,?)";
			
			pst = DBUtils.getPreparedStatement(sql);
			
			pst.setString(1, emp.getEname());
			pst.setString(2, emp.getEemail());
			pst.setString(3, emp.getEpassword());
			pst.setString(4, emp.getEdesignation());
			pst.setString(5, emp.getEaddress());
			
			
			int r = pst.executeUpdate();
			
			if(r > 0){
				inserted = true;
			}
			
			DBUtils.closeResources(rs,pst,stmt,conn);
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		return inserted;
	}
	
	
		
	//Update a Employee Details of Specific eid
	public boolean updateEmployee(Employee emp){
		boolean updated = false;
		String sql = "update employee SET ename=?,eemail=?,epassword=?,edesignation=?,eaddress=?  WHERE eid=?";
		conn = DBUtils.getConnection("employeelawdb");
		pst = DBUtils.getPreparedStatement(sql);
		try{
			pst.setString(1, emp.getEname());
			pst.setString(2, emp.getEemail());
			pst.setString(3, emp.getEpassword());
			pst.setString(4, emp.getEdesignation());
			pst.setString(5, emp.getEaddress());
			pst.setInt(6, emp.getEid());
			
			int r = pst.executeUpdate();
			if(r != 0){
				updated = true;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		DBUtils.closeResources(rs, pst, stmt, conn);
		return updated;
	}
	
	//Delete a employee of specific eid
	public boolean deleteEmployee(int eid){
		boolean deleted = false;
		conn = DBUtils.getConnection("employeelawdb");
		String sql = "delete from employee WHERE eid="+eid;
		stmt = DBUtils.getSimpleStatement();
		try{
			
			int r = stmt.executeUpdate(sql);
			if(r > 0)
				deleted = true;
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		DBUtils.closeResources(rs, pst, stmt, conn);
		return deleted;
	}	
		
		
	
}

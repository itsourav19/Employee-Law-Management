package utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.CAuthority;
import bean.Comments;
import bean.Employee;
import bean.Request;
import bean.Sections;

public class CommonUtils {

	Connection conn = null;
	Statement stmt = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	//Login Validation of Employee/ Senior Employee
	public Employee validateEmployee(String eemail,String epassword,String edesignation){
		Employee emp = null;
		conn = DBUtils.getConnection("employeelawdb");
		String sql = "select * from employee WHERE eemail=? AND epassword=? AND edesignation=?";
		pst = DBUtils.getPreparedStatement(sql);
		try{
			pst.setString(1, eemail);
			pst.setString(2, epassword);
			pst.setString(3, edesignation);
			rs = pst.executeQuery();
			if(rs != null){
				while(rs.next()){
					emp = new Employee(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
				}
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		DBUtils.closeResources(rs, pst, stmt, conn);
		return emp;
	}
	
	//Login Validation of CAT
	public CAuthority validateCAT(String email,String password){
		CAuthority caty = null;
		conn = DBUtils.getConnection("employeelawdb");
		String sql = "select * from cat WHERE email=? AND password=?";
		pst = DBUtils.getPreparedStatement(sql);
		try{
			pst.setString(1, email);
			pst.setString(2, password);
			
			rs = pst.executeQuery();
			if(rs != null){
				while(rs.next()){
					caty = new CAuthority(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
				}
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		DBUtils.closeResources(rs, pst, stmt, conn);
		return caty;
	}
	
	//method returning a Employee object having particular Employee ID
		public Employee getEmployee(int eid){
			Employee emp = null;
			
			conn = DBUtils.getConnection("employeelawdb");
			
			String sql = "select * from employee where eid="+eid;
			
			stmt = DBUtils.getSimpleStatement();
			
			try{
				rs = stmt.executeQuery(sql);
				
				if(rs != null){
					while(rs.next()){
						emp = new Employee(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
					}
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
			
			DBUtils.closeResources(rs,pst,stmt,conn);
			
			return emp;
		}
		
		
		public Request getComplaint(int rid){
			Request rqst= null;
			
			conn = DBUtils.getConnection("employeelawdb");
			
			String sql = "select * from request where rid="+rid;
			
			stmt = DBUtils.getSimpleStatement();
			
			try{
				rs = stmt.executeQuery(sql);
				
				if(rs != null){
					while(rs.next()){
						rqst = new Request(rs.getInt(1),rs.getString(2),null,rs.getString(4),null,null,null);
						Employee emp = new Employee();
						emp.setEid(rs.getInt(5));
						Employee off = new Employee();
						off.setEid(rs.getInt(6));
						Sections sec = new Sections();
						sec.setSid(rs.getInt(7));
						rqst.setEmp(emp);
						rqst.setEmp(off);
						rqst.setSec(sec);
					}
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
			
			DBUtils.closeResources(rs,pst,stmt,conn);
			
			return rqst;
		}
		
		
		public List<Request> getComplaintAgainstOfficer(int oeid){
			List<Request> clist = new ArrayList<Request>();
			conn = DBUtils.getConnection("employeelawdb");
			String sql = "select * from request where oeid="+oeid;
			stmt = DBUtils.getSimpleStatement();
			Request rqst = null;
			try{
				rs = stmt.executeQuery(sql);
				if(rs != null){
					while(rs.next()){
						rqst = new Request(rs.getInt(1),rs.getString(2),null,rs.getString(4),null,null,null);
						
						Employee emp = new Employee();
						emp.setEid(rs.getInt(5));
						Sections sec = new Sections();
						sec.setSid(rs.getInt(7));
						rqst.setEmp(emp);
						rqst.setSec(sec);
						
						clist.add(rqst);
					}
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
			DBUtils.closeResources(rs, pst, stmt, conn);
			
			return clist;
		}
		
	
	//Method See Complain Status
		public String getComplainStatus(int rid){
			Request rqst=null;
			String rstatus = null;
			conn = DBUtils.getConnection("employeelawdb");
			String sql = "select rstatus from request WHERE rid="+rid;
			stmt = DBUtils.getSimpleStatement();
			try{
				rs = stmt.executeQuery(sql);
				if(rs != null){
					while(rs.next()){
						rstatus = rs.getString(1);
						
					}
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
			DBUtils.closeResources(rs, pst, stmt, conn);
			
			return rstatus;
		}
		
	// Method get all complain/Request 
		public List<Request> getAllComplaint(){
			List<Request> clist = new ArrayList<Request>();
			conn = DBUtils.getConnection("employeelawdb");
			String sql = "select * from request";
			stmt = DBUtils.getSimpleStatement();
			Request rqst = null;
			try{
				rs = stmt.executeQuery(sql);
				if(rs != null){
					while(rs.next()){
						rqst = new Request(rs.getInt(1),rs.getString(2),null,rs.getString(4),null,null,null);
						
						Employee emp = new Employee();
						emp.setEid(rs.getInt(5));
						Sections sec = new Sections();
						sec.setSid(rs.getInt(7));
						rqst.setEmp(emp);
						rqst.setSec(sec);
						
						clist.add(rqst);
					}
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
			DBUtils.closeResources(rs, pst, stmt, conn);
			
			return clist;
		}
		
	//Method write Comment/ Review of any Complain
		public boolean writeCommentByCAT(Comments comment){
			boolean inserted = false;
			try{
				conn = DBUtils.getConnection("employeelawdb");
				
				String sql = "insert into comments (commenttext,rid,cid) values (?,?,?)";
				
				pst = DBUtils.getPreparedStatement(sql);
				
				pst.setString(1, comment.getCommenttext());
				pst.setInt(2, comment.getRqst().getRid());
				pst.setInt(3, comment.getCaty().getCid());
				//pst.setInt(4, comment.getEmp().getEid());
				int r = pst.executeUpdate();
				
				if(r > 0){
					inserted = true;
				}
				
				DBUtils.closeResources(rs,pst,stmt,conn);
				
			}catch(SQLException e){
				e.printStackTrace();
			}
			
			return inserted;
		} 
		
		
		public boolean writeCommentByEmp(Comments comment){
			boolean inserted = false;
			try{
				conn = DBUtils.getConnection("employeelawdb");
				
				String sql = "insert into comments (commenttext,rid,eid) values (?,?,?)";
				
				pst = DBUtils.getPreparedStatement(sql);
				
				pst.setString(1, comment.getCommenttext());
				pst.setInt(2, comment.getRqst().getRid());
				pst.setInt(3, comment.getEmp().getEid());
				//pst.setInt(4, comment.getEmp().getEid());
				int r = pst.executeUpdate();
				
				if(r > 0){
					inserted = true;
				}
				
				DBUtils.closeResources(rs,pst,stmt,conn);
				
			}catch(SQLException e){
				e.printStackTrace();
			}
			
			return inserted;
		} 
		
	//Method show all sections
		public List<Sections> getAllSections(){
			List<Sections> seclist = new ArrayList<Sections>();
			conn = DBUtils.getConnection("employeelawdb");
			String sql = "select * from sections";
			stmt = DBUtils.getSimpleStatement();
			
			Sections sec = null;
			try{
				rs = stmt.executeQuery(sql);
				if(rs != null){
					while(rs.next()){
						sec = new Sections(rs.getInt(1),rs.getString(2));
						seclist.add(sec);
					}
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
			DBUtils.closeResources(rs, pst, stmt, conn);
			
			return seclist;
		}
		
		public List<Comments> getAllComments(int rid){
			List<Comments> comlist = new ArrayList<Comments>();
			conn = DBUtils.getConnection("employeelawdb");
			String sql = "select * from comments where rid="+rid;
			stmt = DBUtils.getSimpleStatement();
			Comments comment=null;
			try{
				rs = stmt.executeQuery(sql);
				if(rs != null){
					while(rs.next()){
						comment = new Comments(rs.getInt(1),rs.getString(2),null,null,null);
						Request rqst=new Request();
						rqst.setRid(rs.getInt(3));
						CAuthority cat=new CAuthority();
						cat.setCid(rs.getInt(4));
						Employee emp=new Employee();
						emp.setEid(rs.getInt(5));
						
						comlist.add(comment);
					}
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
			DBUtils.closeResources(rs, pst, stmt, conn);
			
			return comlist;
		}
		
	
}

package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBUtils {

	private static Connection conn = null;
	private static Statement st = null;
	private static PreparedStatement pst = null;
	private static ResultSet rs = null;
	
	public static Connection getConnection(String dbName){
		String url = "jdbc:mysql://localhost:3306/"+dbName;
		String user = "root";
		String pwd = "12345678";
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, user, pwd);
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return conn;
	}
	
	public static Statement getSimpleStatement(){
		try{
		if(conn != null){
			st = conn.createStatement();
		}
		}catch(SQLException e){
			e.printStackTrace();
		}
	return st;
	}
	
	public static PreparedStatement getPreparedStatement(String sql){
		try{
			if(conn != null){
				pst = conn.prepareStatement(sql);
			}
			}catch(SQLException e){
				e.printStackTrace();
			}
		return pst;
	}
		
	public static void closeResources(ResultSet rs,PreparedStatement pst,Statement stmt,Connection conn){
		try{
			if(rs != null)
				rs.close();
			if(pst != null)
				pst.close();
			if(stmt != null)
				stmt.close();
			if(conn != null)
				conn.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
	}

	
}

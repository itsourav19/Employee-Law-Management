package test;

import bean.CAuthority;
import bean.Employee;
import utils.CATUtils;
import utils.EmployeeUtils;

public class Test {

	public static void main(String[] args) {
		
		/*CAuthority caty = new CAuthority (0,"rahul@gmail.com","rahul123","Rahul Singh");
		CATUtils c = new CATUtils ();
		c.addCAT(caty);*/
		
		//Employee emp=new Employee(2,"Natasha Choradia","n@gmail.com","123456789","Senior Employee","Kolkata");
		//EmployeeUtils e=new EmployeeUtils();
		//e.deleteEmployee(2);
		
	}

}

package utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Employee;
import bean.Sections;

public class SectionsUtils {

	Connection conn = null;
	Statement stmt = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	//Method Add Sections
	public boolean addSection(Sections sec){
		boolean inserted = false;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DBUtils.getConnection("employeelawdb");
			
			String sql = "insert into sections (sname) values (?)";
			
			pst = DBUtils.getPreparedStatement(sql);
			
			pst.setString(1,sec.getSname());
							
			int r = pst.executeUpdate();
			
			ResultSet rs = pst.getGeneratedKeys();
			
			DBUtils.closeResources(rs,pst,stmt,conn);
			
		}catch(SQLException e){
			e.printStackTrace();
		}catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		return inserted;
	}
	
	//Method update Sections
	public boolean updateSection(Sections sec){
		boolean updated = false;
		String sql = "update sections SET sname=? WHERE sid=?";
		conn = DBUtils.getConnection("employeelawdb");
		pst = DBUtils.getPreparedStatement(sql);
		try{
			pst.setString(1, sec.getSname());
						
			int r = pst.executeUpdate();
			if(r != 0){
				updated = true;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		DBUtils.closeResources(rs, pst, stmt, conn);
		return updated;
	}
	
	//Delete a section of specific sid
	public boolean deleteSection(int sid){
		boolean deleted = false;
		conn = DBUtils.getConnection("employeelawdb");
		String sql = "delete from sections WHERE sid="+sid;
		stmt = DBUtils.getSimpleStatement();
		try{
			
			int r = stmt.executeUpdate(sql);
			if(r > 0)
				deleted = true;
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		DBUtils.closeResources(rs, pst, stmt, conn);
		return deleted;
	}
}

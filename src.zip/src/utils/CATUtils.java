package utils;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.CAuthority;
import bean.Employee;

public class CATUtils {

	Connection conn = null;
	Statement stmt = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	public int addCAT(CAuthority caty){
		
		int cid=0;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DBUtils.getConnection("employeelawdb");
			
			String sql = "insert into cat (email,password,name) values (?,?,?)";
			
			pst = DBUtils.getPreparedStatement(sql);
			
			pst.setString(1,caty.getEmail());
			pst.setString(2,caty.getPassword());
			pst.setString(3,caty.getName());
			
			int r = pst.executeUpdate();
			
			ResultSet rs = pst.getGeneratedKeys();
			
			DBUtils.closeResources(rs,pst,stmt,conn);
			
		}catch(SQLException e){
			e.printStackTrace();
		}catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		
		return cid;
	}
	
	//Update a CAT Details of Specific cid
		public boolean updateCAT(CAuthority caty){
			boolean updated = false;
			String sql = "update cat SET email=?,password=?,name=?  WHERE cid=?";
			conn = DBUtils.getConnection("employeelawdb");
			pst = DBUtils.getPreparedStatement(sql);
			try{
				pst.setString(1, caty.getEmail());
				pst.setString(2, caty.getPassword());
				pst.setString(3, caty.getName());
				
				int r = pst.executeUpdate();
				if(r != 0){
					updated = true;
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
			DBUtils.closeResources(rs, pst, stmt, conn);
			return updated;
		}
		
		//Delete a CAT of specific cid
		public boolean deleteCAT(int cid){
			boolean deleted = false;
			conn = DBUtils.getConnection("employeelawdb");
			String sql = "delete from cat WHERE cid="+cid;
			stmt = DBUtils.getSimpleStatement();
			try{
				
				int r = stmt.executeUpdate(sql);
				if(r > 0)
					deleted = true;
				
			}catch(SQLException e){
				e.printStackTrace();
			}
			DBUtils.closeResources(rs, pst, stmt, conn);
			return deleted;
		}	
			
			

}

package bean;

import java.io.File;

public class Request {

	private int rid;
	private String rdescription;
	private File rfile;
	private String rstatus;
	private Employee emp;
	private Employee off;
	private Sections sec;

	public Request() {
		super();
	}

	public Request(int rid, String rdescription, File rfile, String rstatus, Employee emp, Employee off, Sections sec) {
		super();
		this.rid = rid;
		this.rdescription = rdescription;
		this.rfile = rfile;
		this.rstatus = rstatus;
		this.emp = emp;
		this.off = off;
		this.sec = sec;
	}

	public Request(int rid, String rstatus) {

		this.rid = rid;
		this.rstatus = rstatus;
		this.rstatus = rstatus;
		this.emp = emp;
		this.sec = sec;
	}

	public Request(int rid, String rdescription, String rstatus, Employee emp, Sections sec) {
		this.rid = rid;
		this.rdescription = rdescription;
	}

	public int getRid() {
		return rid;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public String getRdescription() {
		return rdescription;
	}

	public void setRdescription(String rdescription) {
		this.rdescription = rdescription;
	}

	public File getRfile() {
		return rfile;
	}

	public void setRfile(File rfile) {
		this.rfile = rfile;
	}

	public String getRstatus() {
		return rstatus;
	}

	public void setRstatus(String rstatus) {
		this.rstatus = rstatus;
	}

	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}

	public Sections getSec() {
		return sec;
	}

	public void setSec(Sections sec) {
		this.sec = sec;
	}

}

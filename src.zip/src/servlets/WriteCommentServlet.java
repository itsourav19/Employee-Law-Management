package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.stream.events.Comment;

import bean.CAuthority;
import bean.Comments;
import bean.Employee;
import bean.Request;
import utils.CommonUtils;


@WebServlet("/writeComment")
public class WriteCommentServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int cid=Integer.parseInt(request.getParameter("cid"));
		int rid=Integer.parseInt(request.getParameter("rid"));
		String commenttext=request.getParameter("commenttext");
		
		Request rqst=new Request();
		rqst.setRid(rid);
		
		CAuthority cat=new CAuthority();
		cat.setCid(cid);
			
		Comments com=new Comments(0,commenttext,rqst,cat,null);
		CommonUtils u=new CommonUtils();
		if (u.writeCommentByCAT(com)) {
			RequestDispatcher dis = request.getRequestDispatcher("CATHome.jsp");
			dis.forward(request, response);
			System.out.println("Comment Registered..!");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

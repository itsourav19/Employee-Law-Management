package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utils.CommonUtils;


@WebServlet("/checkComplaintStatus")
public class CheckComplaintStatusServlet extends HttpServlet {
	
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int rid=Integer.parseInt(request.getParameter("rid"));
		CommonUtils u=new CommonUtils();
		String rstatus=u.getComplainStatus(rid);
		request.getSession().setAttribute("rstatus", rstatus);
		response.sendRedirect("CheckStatus.jsp");
		System.out.println(rstatus);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}

package servlets;

import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Employee;
import bean.Request;
import bean.Sections;
import utils.CommonUtils;
import utils.RequestUtils;


@WebServlet("/UpdateComplaintStatus")
public class UpdateComplaintStatus extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int rid=Integer.parseInt(request.getParameter("rid"));
		
		
		String rstatus= request.getParameter("rstatus");
			
		
		Request rqst=new Request(rid,rstatus);
		
		RequestUtils u=new RequestUtils();
		if(u.updateComplain(rqst)){
			request.setAttribute("action", "Complaint Update");
			request.setAttribute("result", "success");
			RequestDispatcher dis = request.getRequestDispatcher("CATHome.jsp");
			dis.forward(request, response);
			System.out.println("Complaint Updated..!");
		}else{
			request.setAttribute("action", "Complaint Registration");
			request.setAttribute("result", "failed");
			RequestDispatcher dis = request.getRequestDispatcher("UpdateComplaint.jsp");
			dis.forward(request, response);
			System.out.println("Complaint Not Updated..!");
		}

		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}

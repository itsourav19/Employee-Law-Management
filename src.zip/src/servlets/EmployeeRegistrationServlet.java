package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Employee;
import utils.EmployeeUtils;


@WebServlet("/registerEmployee")
public class EmployeeRegistrationServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ename=request.getParameter("ename");
		String epassword=request.getParameter("epassword"); 
		String eemail=request.getParameter("eemail");
		String eaddress=request.getParameter("eaddress");
		String edesignation=request.getParameter("edesignation");
		
		Employee emp=new Employee(0, ename, eemail, epassword, edesignation, eaddress);
		EmployeeUtils eutil= new EmployeeUtils();
		if(eutil.registerEmployee(emp)) {
			request.setAttribute("action", "Employee Registration");
			request.setAttribute("result", "success");
			RequestDispatcher dis = request.getRequestDispatcher("Login.jsp");
			dis.forward(request, response);
			System.out.println("Success..!");
		}else {
			request.setAttribute("action", "Employee Registration");
			request.setAttribute("result", "failed");
			RequestDispatcher dis = request.getRequestDispatcher("EmployeeRegistration.jsp");
			dis.forward(request, response);
			System.out.println("Failed..!");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
